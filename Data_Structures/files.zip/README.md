# Welcome to your Lab Sandbox

We're glad you're here! You can leverage this README to get 
started on your in-browser assessments for this course. 

# What is a Lab Sandbox?
- Lab Sandboxes are fully optional and in-browser environments 
that you can use to complete your coursework. They are pre-configured 
by Coursera with all the dependencies (libraries, packages) you'll 
need to complete the practice and graded course assessments and 
run relevant test cases. You do not need to install any tools on 
your local computer. All work can be completed in the sandbox.
These environments are not connected to your local desktop.

# Using Your Lab Sandbox:
The Lab Sandbox environment for this course uses the Visual 
Studio Code Editor. Here are some tips to get started:

- **UPLOAD FILES**: Drag files from your Desktop to your Lab Sandbox.

- **DOWNLOAD FILES**: Drag individual files from your lab browser 
  to your local desktop, or use the **Files -> Download** option in the
  Labs Help toolbar to download your full lab workspace.

- **CREATE NEW FILES**: Select File -> New File from the menu at 
  the upper lefthand corner.

- **OPEN FILES**: Select File -> Open from the menu and type in the 
  /home/coder/project directory (this should open by default). 
  You can click on the filenames or folders to access them.

- **SAVING FILES**: Your files will autosave every 2 seconds in 
  this environment. To manually save, you can select command + S.
  Note: Within VSCode all of your work should be saved in the 
  /home/coder/project directory.  By saving your work in this 
  directory, your work will persist between your lab sessions 
  for the duration of this course.

- **UNZIP FILES**: After uploading a compressed file, navigate to 
  terminal. You can unzip a .zip file by typing 
  the following in your command line:<
  **"unzip [your-path-to-your-file-and-filename"**

# How can I get started?
   1. First, read the Getting Started with your Lab readme for 
      important course-specific notes.
   2. Download any assessment or starter files directly from 
      the course instructions. You can download most files directly 
      by clicking on them, but for any case where the file is 
      opened in a new browser tab, please right click on a blank
      area of the browser page, and click “Save As” to save 
      your file locally.
   3. Upload your files into your VSCode Lab Sandbox in-browser.
   4. Once you have completed your work in the sandbox, 
      save your work and download it locally.
   5. To receive a score for your work within Coursera, upload your 
      assessment files by following the course instructions 
      listed within the assignment. If you are completing 
      programming work for a quiz assessment, you can use your 
      Lab environment to complete your work and then select your 
      responses within the quiz.
   
_________________________________________________________________________________________________

## Frequently Asked Questions:

### How can I get help with my environment?
Coursera currently maintains these Lab Sandboxes. 
Course team members and instructors do not have the ability to modify
or troubleshoot these sandbox environments, so **please do not contact** the
course team or your instructor for platform-related lab sandbox troubleshooting.
If you do run into any time sensitive platform issues, 
please reach out to our 24/7 chat support instead through the Learner Help Center here:
- Learner Help Center: https://learner.coursera.help/hc

If you have any general feedback about the sandbox experience, 
we'd love to hear from you about your experience! You can reach out to us for 
any non time-sensitive feedback through this survey.
- Lab Sandbox Survey Link: https://docs.google.com/forms/d/e/1FAIpQLScwaSadSi0tIr9_YNpEbGR4-quoUe7Yo6-aBXChcVJN9N3UcQ/viewform


### How long will I have access to my files?
You will have access to these files during your active course 
enrollment. If you would like to access your files past your 
active course enrollment, please be sure to download these to 
your computer prior to the last day of  your subscription or 
course access.

### Can I push my code to Github from this environment?
Yes. Git is installed in this environment, so you can use the 
terminal feature to run git commands.

### How can I use the terminal?
You can use terminal by selecting Terminal -> New Terminal 
from your menubar. More information on using the VSCode integrated 
terminal can be found here: 
https://code.visualstudio.com/docs/editor/integrated-terminal

### How can I leverage the debugger tool?
More information on this can be found here: 
https://code.visualstudio.com/docs/editor/debugging

### How can I compile my code?
More information on this can be found in the Getting Started 
with your Lab Sandbox readme and the article below: 
https://code.visualstudio.com/docs/cpp/config-linux
