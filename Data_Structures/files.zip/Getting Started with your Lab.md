# Getting Started with your Lab Sandbox

## What libraries and languages are already installed in this environment? 
- GCC9 Compiler
- C/C++ Compile Run extension in VSCode
- C/C++ IntelliSense, debugging, and code browsing extension in VSCode 
- Java version - Openjdk version "11.0.7" 
- Python 3 

## Steps to unzip a folder

If you have an unzip folder uploaded in the project directory, 
you can use below command to unzip it

"unzip <zipped folder name>.zip"
   
To copy a zip folder to the VSCode just drag and drop the file 
from your system to your workspace. 

## Steps to execute the code through VSCode editor
1. Create files with relevant extension .java (for Java Class files),
   .cpp (For C++ class files), .py for Python files
2. Make sure your code doesnot have any syntax error. For Java 
   make sure that the file name is same name as public class
3. To execute the code >> right click on file name >> Run code 
   OR Navigate to Menu from top left >> Run >> Run without debug
4. To run your code in debug mode >> Add a break point >> Navigate 
   to Menu from top left >> Run >> Start Debugging

## Steps to execute C++ code through terminal (prefered way)
1. All C++ code files must have ".cpp" extension
2. Make sure your code doesnot have any syntax error
3. Open Terminal >> Navigate to menu >> Terminal >> New Terminal 
   (or use the shortcut Shift + CTRL + `)
4. Enter the below command to compile and execute the code.

cd "/home/coder/project/"sub directory" && g++ program_filename.cpp 
    -o <output filename> && "/home/coder/project/"<output filename>

Example - cd "/home/coder/project/week1" && g++ AddTwoNumbers.cpp 
        -o AddTwoNumbers && "/home/coder/project/"AddTwoNumbers

## Steps to execute Java code through terminal (prefered way)
1. All Java code files must have ".java" extension
2. Make sure your code doesnot have any syntax error
3. Open Terminal >> Navigate to menu >> Terminal >> New Terminal 
   (or use the shortcut Shift + CTRL + `)
4. Enter the below command to compile and execute the code.

cd "/home/coder/project/"sub directory"" && javac "program_filename".java 
&& java "/home/coder/project/"<output filename>

Example - cd "/home/coder/project/week1" && g++ AddTwoNumbers.java 
&& java "/home/coder/project/"AddTwoNumbers

## Steps to execute Python code through terminal (prefered way) - </b>
1. All Python code files must have ".py" extension
2. Make sure your code doesnot have any syntax error
3. Open Terminal >> Navigate to menu >> Terminal >> New Terminal 
   (or use the shortcut Shift + CTRL + `)
4. Enter the below command to compile and execute the code.

python -u "/home/coder/project/"sub directory"/"program_filename".py"
  
Example - python -u "/home/coder/project/week1/APlusB.py"